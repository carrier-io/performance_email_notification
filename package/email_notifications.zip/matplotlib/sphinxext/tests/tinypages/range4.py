from matplotlib import pyplot as plt

plt.figure()
plt.plot(range(4))
plt.show()
