Requests-toolbelt is written and maintained by Ian Cordasco, Cory Benfield and
various contributors:

Development Lead
````````````````

- Ian Cordasco

- Cory Benfield


Requests
````````

- Kenneth Reitz <me@kennethreitz.com> and various contributors


Urllib3
```````

- Andrey Petrov <andrey.petrov@shazow.net>


Patches and Suggestions
```````````````````````

- Jay De Lanoy <jay@delanoy.co>

- Zhaoyu Luo <luozhaoyu90@gmail.com>

- Markus Unterwaditzer <markus@unterwaditzer.net>

- Bryce Boe <bbzbryce@gmail.com> (@bboe)

- Dan Lipsitt (https://github.com/DanLipsitt)

- Cea Stapleton (http://www.ceastapleton.com)

- Patrick Creech <pcreech@redhat.com>

- Mike Lambert (@mikelambert)

- Ryan Barrett (https://snarfed.org/)

- Victor Grau Serrat (@lacabra)

- Yorgos Pagles <yorgos@pagles.org>

- Thomas Hauk <thauk@copperleaf.com>

- Achim Herwig <python@wodca.de>

- Ryan Ashley <rashley-iqt>